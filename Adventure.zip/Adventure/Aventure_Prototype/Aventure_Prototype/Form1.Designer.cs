﻿namespace Aventure_Prototype
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbCharCr = new System.Windows.Forms.GroupBox();
            this.btnCharCon = new System.Windows.Forms.Button();
            this.gbCharStats = new System.Windows.Forms.GroupBox();
            this.btnRes = new System.Windows.Forms.Button();
            this.btnCharCR = new System.Windows.Forms.Button();
            this.txtBP = new System.Windows.Forms.TextBox();
            this.lblBP = new System.Windows.Forms.Label();
            this.btnIntelP = new System.Windows.Forms.Button();
            this.btnDexP = new System.Windows.Forms.Button();
            this.btnStrP = new System.Windows.Forms.Button();
            this.txtMana = new System.Windows.Forms.TextBox();
            this.txtHealth = new System.Windows.Forms.TextBox();
            this.lblMana = new System.Windows.Forms.Label();
            this.lblHealth = new System.Windows.Forms.Label();
            this.txtIntel = new System.Windows.Forms.TextBox();
            this.txtDex = new System.Windows.Forms.TextBox();
            this.txtStr = new System.Windows.Forms.TextBox();
            this.lblIntel = new System.Windows.Forms.Label();
            this.lblDex = new System.Windows.Forms.Label();
            this.lblStr = new System.Windows.Forms.Label();
            this.lbClSpec = new System.Windows.Forms.ListBox();
            this.lbClass = new System.Windows.Forms.ListBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblClSpec = new System.Windows.Forms.Label();
            this.lblClass = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtCharName = new System.Windows.Forms.TextBox();
            this.txtCharClass = new System.Windows.Forms.TextBox();
            this.txtCharSpec = new System.Windows.Forms.TextBox();
            this.txtCharHealth = new System.Windows.Forms.TextBox();
            this.txtCharMana = new System.Windows.Forms.TextBox();
            this.txtCharXP = new System.Windows.Forms.TextBox();
            this.lblCharHealth = new System.Windows.Forms.Label();
            this.lblCharMana = new System.Windows.Forms.Label();
            this.lblCharXP = new System.Windows.Forms.Label();
            this.tbChar = new System.Windows.Forms.TabControl();
            this.tpStats = new System.Windows.Forms.TabPage();
            this.txtCharGold = new System.Windows.Forms.TextBox();
            this.lblGold = new System.Windows.Forms.Label();
            this.txtCharLVL = new System.Windows.Forms.TextBox();
            this.txtCharStIntel = new System.Windows.Forms.TextBox();
            this.txtCharStDex = new System.Windows.Forms.TextBox();
            this.txtCharStStr = new System.Windows.Forms.TextBox();
            this.lblI = new System.Windows.Forms.Label();
            this.lblD = new System.Windows.Forms.Label();
            this.lblS = new System.Windows.Forms.Label();
            this.tpInv = new System.Windows.Forms.TabPage();
            this.pbMob = new System.Windows.Forms.PictureBox();
            this.btnShowMob = new System.Windows.Forms.Button();
            this.lblMobName = new System.Windows.Forms.Label();
            this.lblMobLvl = new System.Windows.Forms.Label();
            this.lblMlvl = new System.Windows.Forms.Label();
            this.txtMStr = new System.Windows.Forms.TextBox();
            this.txtMDex = new System.Windows.Forms.TextBox();
            this.txtMIntel = new System.Windows.Forms.TextBox();
            this.txtMHealth = new System.Windows.Forms.TextBox();
            this.txtMMana = new System.Windows.Forms.TextBox();
            this.lblMStr = new System.Windows.Forms.Label();
            this.lblMDex = new System.Windows.Forms.Label();
            this.lblMIntel = new System.Windows.Forms.Label();
            this.lblMHealth = new System.Windows.Forms.Label();
            this.lblMMana = new System.Windows.Forms.Label();
            this.btnMHit = new System.Windows.Forms.Button();
            this.lblMXP = new System.Windows.Forms.Label();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.btnRemItem = new System.Windows.Forms.Button();
            this.lbPlayInv = new System.Windows.Forms.ListBox();
            this.grbCharCr.SuspendLayout();
            this.gbCharStats.SuspendLayout();
            this.tbChar.SuspendLayout();
            this.tpStats.SuspendLayout();
            this.tpInv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMob)).BeginInit();
            this.SuspendLayout();
            // 
            // grbCharCr
            // 
            this.grbCharCr.Controls.Add(this.btnCharCon);
            this.grbCharCr.Controls.Add(this.gbCharStats);
            this.grbCharCr.Controls.Add(this.lbClSpec);
            this.grbCharCr.Controls.Add(this.lbClass);
            this.grbCharCr.Controls.Add(this.txtName);
            this.grbCharCr.Controls.Add(this.lblClSpec);
            this.grbCharCr.Controls.Add(this.lblClass);
            this.grbCharCr.Controls.Add(this.lblName);
            this.grbCharCr.Location = new System.Drawing.Point(13, 13);
            this.grbCharCr.Name = "grbCharCr";
            this.grbCharCr.Size = new System.Drawing.Size(775, 244);
            this.grbCharCr.TabIndex = 0;
            this.grbCharCr.TabStop = false;
            this.grbCharCr.Text = "Character Creation";
            // 
            // btnCharCon
            // 
            this.btnCharCon.Enabled = false;
            this.btnCharCon.Location = new System.Drawing.Point(255, 204);
            this.btnCharCon.Name = "btnCharCon";
            this.btnCharCon.Size = new System.Drawing.Size(75, 23);
            this.btnCharCon.TabIndex = 7;
            this.btnCharCon.Text = "Confirm";
            this.btnCharCon.UseVisualStyleBackColor = true;
            this.btnCharCon.Click += new System.EventHandler(this.btnCharCon_Click);
            // 
            // gbCharStats
            // 
            this.gbCharStats.Controls.Add(this.btnRes);
            this.gbCharStats.Controls.Add(this.btnCharCR);
            this.gbCharStats.Controls.Add(this.txtBP);
            this.gbCharStats.Controls.Add(this.lblBP);
            this.gbCharStats.Controls.Add(this.btnIntelP);
            this.gbCharStats.Controls.Add(this.btnDexP);
            this.gbCharStats.Controls.Add(this.btnStrP);
            this.gbCharStats.Controls.Add(this.txtMana);
            this.gbCharStats.Controls.Add(this.txtHealth);
            this.gbCharStats.Controls.Add(this.lblMana);
            this.gbCharStats.Controls.Add(this.lblHealth);
            this.gbCharStats.Controls.Add(this.txtIntel);
            this.gbCharStats.Controls.Add(this.txtDex);
            this.gbCharStats.Controls.Add(this.txtStr);
            this.gbCharStats.Controls.Add(this.lblIntel);
            this.gbCharStats.Controls.Add(this.lblDex);
            this.gbCharStats.Controls.Add(this.lblStr);
            this.gbCharStats.Location = new System.Drawing.Point(336, 20);
            this.gbCharStats.Name = "gbCharStats";
            this.gbCharStats.Size = new System.Drawing.Size(417, 213);
            this.gbCharStats.TabIndex = 6;
            this.gbCharStats.TabStop = false;
            this.gbCharStats.Text = "Character Stats";
            // 
            // btnRes
            // 
            this.btnRes.Location = new System.Drawing.Point(282, 42);
            this.btnRes.Name = "btnRes";
            this.btnRes.Size = new System.Drawing.Size(75, 23);
            this.btnRes.TabIndex = 21;
            this.btnRes.Text = "Reset";
            this.btnRes.UseVisualStyleBackColor = true;
            this.btnRes.Click += new System.EventHandler(this.btnRes_Click);
            // 
            // btnCharCR
            // 
            this.btnCharCR.Enabled = false;
            this.btnCharCR.Location = new System.Drawing.Point(6, 184);
            this.btnCharCR.Name = "btnCharCR";
            this.btnCharCR.Size = new System.Drawing.Size(75, 23);
            this.btnCharCR.TabIndex = 20;
            this.btnCharCR.Text = "Create";
            this.btnCharCR.UseVisualStyleBackColor = true;
            this.btnCharCR.Click += new System.EventHandler(this.btnCharCR_Click);
            // 
            // txtBP
            // 
            this.txtBP.Enabled = false;
            this.txtBP.Location = new System.Drawing.Point(354, 16);
            this.txtBP.Name = "txtBP";
            this.txtBP.Size = new System.Drawing.Size(49, 20);
            this.txtBP.TabIndex = 19;
            // 
            // lblBP
            // 
            this.lblBP.AutoSize = true;
            this.lblBP.Location = new System.Drawing.Point(279, 19);
            this.lblBP.Name = "lblBP";
            this.lblBP.Size = new System.Drawing.Size(69, 13);
            this.lblBP.TabIndex = 18;
            this.lblBP.Text = "Bonus Points";
            // 
            // btnIntelP
            // 
            this.btnIntelP.Enabled = false;
            this.btnIntelP.Location = new System.Drawing.Point(186, 80);
            this.btnIntelP.Name = "btnIntelP";
            this.btnIntelP.Size = new System.Drawing.Size(34, 20);
            this.btnIntelP.TabIndex = 17;
            this.btnIntelP.Text = "+";
            this.btnIntelP.UseVisualStyleBackColor = true;
            this.btnIntelP.Click += new System.EventHandler(this.btnIntelP_Click);
            // 
            // btnDexP
            // 
            this.btnDexP.Enabled = false;
            this.btnDexP.Location = new System.Drawing.Point(186, 48);
            this.btnDexP.Name = "btnDexP";
            this.btnDexP.Size = new System.Drawing.Size(34, 20);
            this.btnDexP.TabIndex = 16;
            this.btnDexP.Text = "+";
            this.btnDexP.UseVisualStyleBackColor = true;
            this.btnDexP.Click += new System.EventHandler(this.btnDexP_Click);
            // 
            // btnStrP
            // 
            this.btnStrP.Enabled = false;
            this.btnStrP.Location = new System.Drawing.Point(186, 17);
            this.btnStrP.Name = "btnStrP";
            this.btnStrP.Size = new System.Drawing.Size(34, 20);
            this.btnStrP.TabIndex = 15;
            this.btnStrP.Text = "+";
            this.btnStrP.UseVisualStyleBackColor = true;
            this.btnStrP.Click += new System.EventHandler(this.btnStrP_Click);
            // 
            // txtMana
            // 
            this.txtMana.Enabled = false;
            this.txtMana.Location = new System.Drawing.Point(80, 143);
            this.txtMana.Name = "txtMana";
            this.txtMana.Size = new System.Drawing.Size(100, 20);
            this.txtMana.TabIndex = 9;
            // 
            // txtHealth
            // 
            this.txtHealth.Enabled = false;
            this.txtHealth.Location = new System.Drawing.Point(80, 111);
            this.txtHealth.Name = "txtHealth";
            this.txtHealth.Size = new System.Drawing.Size(100, 20);
            this.txtHealth.TabIndex = 8;
            // 
            // lblMana
            // 
            this.lblMana.AutoSize = true;
            this.lblMana.Location = new System.Drawing.Point(6, 146);
            this.lblMana.Name = "lblMana";
            this.lblMana.Size = new System.Drawing.Size(34, 13);
            this.lblMana.TabIndex = 7;
            this.lblMana.Text = "Mana";
            // 
            // lblHealth
            // 
            this.lblHealth.AutoSize = true;
            this.lblHealth.Location = new System.Drawing.Point(6, 114);
            this.lblHealth.Name = "lblHealth";
            this.lblHealth.Size = new System.Drawing.Size(38, 13);
            this.lblHealth.TabIndex = 6;
            this.lblHealth.Text = "Health";
            // 
            // txtIntel
            // 
            this.txtIntel.Enabled = false;
            this.txtIntel.Location = new System.Drawing.Point(80, 80);
            this.txtIntel.Name = "txtIntel";
            this.txtIntel.Size = new System.Drawing.Size(100, 20);
            this.txtIntel.TabIndex = 5;
            // 
            // txtDex
            // 
            this.txtDex.Enabled = false;
            this.txtDex.Location = new System.Drawing.Point(80, 48);
            this.txtDex.Name = "txtDex";
            this.txtDex.Size = new System.Drawing.Size(100, 20);
            this.txtDex.TabIndex = 4;
            // 
            // txtStr
            // 
            this.txtStr.Enabled = false;
            this.txtStr.Location = new System.Drawing.Point(80, 17);
            this.txtStr.Name = "txtStr";
            this.txtStr.Size = new System.Drawing.Size(100, 20);
            this.txtStr.TabIndex = 3;
            // 
            // lblIntel
            // 
            this.lblIntel.AutoSize = true;
            this.lblIntel.Location = new System.Drawing.Point(6, 83);
            this.lblIntel.Name = "lblIntel";
            this.lblIntel.Size = new System.Drawing.Size(61, 13);
            this.lblIntel.TabIndex = 2;
            this.lblIntel.Text = "Intelligence";
            // 
            // lblDex
            // 
            this.lblDex.AutoSize = true;
            this.lblDex.Location = new System.Drawing.Point(6, 51);
            this.lblDex.Name = "lblDex";
            this.lblDex.Size = new System.Drawing.Size(48, 13);
            this.lblDex.TabIndex = 1;
            this.lblDex.Text = "Dexterity";
            // 
            // lblStr
            // 
            this.lblStr.AutoSize = true;
            this.lblStr.Location = new System.Drawing.Point(6, 20);
            this.lblStr.Name = "lblStr";
            this.lblStr.Size = new System.Drawing.Size(47, 13);
            this.lblStr.TabIndex = 0;
            this.lblStr.Text = "Strength";
            // 
            // lbClSpec
            // 
            this.lbClSpec.FormattingEnabled = true;
            this.lbClSpec.Location = new System.Drawing.Point(212, 62);
            this.lbClSpec.Name = "lbClSpec";
            this.lbClSpec.Size = new System.Drawing.Size(100, 43);
            this.lbClSpec.TabIndex = 5;
            this.lbClSpec.SelectedIndexChanged += new System.EventHandler(this.lbClSpec_SelectedIndexChanged);
            // 
            // lbClass
            // 
            this.lbClass.FormattingEnabled = true;
            this.lbClass.Items.AddRange(new object[] {
            "Fighter",
            "Ranger",
            "Wizard"});
            this.lbClass.Location = new System.Drawing.Point(48, 62);
            this.lbClass.Name = "lbClass";
            this.lbClass.Size = new System.Drawing.Size(100, 43);
            this.lbClass.TabIndex = 4;
            this.lbClass.SelectedIndexChanged += new System.EventHandler(this.lbClass_SelectedIndexChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(48, 27);
            this.txtName.MaxLength = 16;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(115, 20);
            this.txtName.TabIndex = 3;
            // 
            // lblClSpec
            // 
            this.lblClSpec.AutoSize = true;
            this.lblClSpec.Location = new System.Drawing.Point(154, 62);
            this.lblClSpec.Name = "lblClSpec";
            this.lblClSpec.Size = new System.Drawing.Size(52, 13);
            this.lblClSpec.TabIndex = 2;
            this.lblClSpec.Text = "Speciality";
            // 
            // lblClass
            // 
            this.lblClass.AutoSize = true;
            this.lblClass.Location = new System.Drawing.Point(7, 62);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(32, 13);
            this.lblClass.TabIndex = 1;
            this.lblClass.Text = "Class";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(7, 30);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(713, 553);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtCharName
            // 
            this.txtCharName.Enabled = false;
            this.txtCharName.Location = new System.Drawing.Point(12, 273);
            this.txtCharName.Name = "txtCharName";
            this.txtCharName.Size = new System.Drawing.Size(115, 20);
            this.txtCharName.TabIndex = 2;
            // 
            // txtCharClass
            // 
            this.txtCharClass.Enabled = false;
            this.txtCharClass.Location = new System.Drawing.Point(13, 299);
            this.txtCharClass.Name = "txtCharClass";
            this.txtCharClass.Size = new System.Drawing.Size(115, 20);
            this.txtCharClass.TabIndex = 3;
            // 
            // txtCharSpec
            // 
            this.txtCharSpec.Enabled = false;
            this.txtCharSpec.Location = new System.Drawing.Point(12, 325);
            this.txtCharSpec.Name = "txtCharSpec";
            this.txtCharSpec.Size = new System.Drawing.Size(115, 20);
            this.txtCharSpec.TabIndex = 4;
            // 
            // txtCharHealth
            // 
            this.txtCharHealth.Enabled = false;
            this.txtCharHealth.Location = new System.Drawing.Point(182, 273);
            this.txtCharHealth.Name = "txtCharHealth";
            this.txtCharHealth.Size = new System.Drawing.Size(37, 20);
            this.txtCharHealth.TabIndex = 5;
            this.txtCharHealth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCharMana
            // 
            this.txtCharMana.Enabled = false;
            this.txtCharMana.Location = new System.Drawing.Point(182, 299);
            this.txtCharMana.Name = "txtCharMana";
            this.txtCharMana.Size = new System.Drawing.Size(37, 20);
            this.txtCharMana.TabIndex = 6;
            this.txtCharMana.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCharXP
            // 
            this.txtCharXP.Enabled = false;
            this.txtCharXP.Location = new System.Drawing.Point(82, 89);
            this.txtCharXP.Name = "txtCharXP";
            this.txtCharXP.Size = new System.Drawing.Size(100, 20);
            this.txtCharXP.TabIndex = 7;
            this.txtCharXP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCharXP.TextChanged += new System.EventHandler(this.txtCharXP_TextChanged);
            // 
            // lblCharHealth
            // 
            this.lblCharHealth.AutoSize = true;
            this.lblCharHealth.Location = new System.Drawing.Point(138, 276);
            this.lblCharHealth.Name = "lblCharHealth";
            this.lblCharHealth.Size = new System.Drawing.Size(38, 13);
            this.lblCharHealth.TabIndex = 8;
            this.lblCharHealth.Text = "Health";
            // 
            // lblCharMana
            // 
            this.lblCharMana.AutoSize = true;
            this.lblCharMana.Location = new System.Drawing.Point(142, 302);
            this.lblCharMana.Name = "lblCharMana";
            this.lblCharMana.Size = new System.Drawing.Size(34, 13);
            this.lblCharMana.TabIndex = 9;
            this.lblCharMana.Text = "Mana";
            // 
            // lblCharXP
            // 
            this.lblCharXP.AutoSize = true;
            this.lblCharXP.Location = new System.Drawing.Point(8, 92);
            this.lblCharXP.Name = "lblCharXP";
            this.lblCharXP.Size = new System.Drawing.Size(60, 13);
            this.lblCharXP.TabIndex = 10;
            this.lblCharXP.Text = "Experience";
            // 
            // tbChar
            // 
            this.tbChar.Controls.Add(this.tpStats);
            this.tbChar.Controls.Add(this.tpInv);
            this.tbChar.Location = new System.Drawing.Point(13, 351);
            this.tbChar.Name = "tbChar";
            this.tbChar.SelectedIndex = 0;
            this.tbChar.Size = new System.Drawing.Size(200, 182);
            this.tbChar.TabIndex = 11;
            // 
            // tpStats
            // 
            this.tpStats.Controls.Add(this.txtCharGold);
            this.tpStats.Controls.Add(this.lblGold);
            this.tpStats.Controls.Add(this.txtCharLVL);
            this.tpStats.Controls.Add(this.txtCharStIntel);
            this.tpStats.Controls.Add(this.lblCharXP);
            this.tpStats.Controls.Add(this.txtCharStDex);
            this.tpStats.Controls.Add(this.txtCharXP);
            this.tpStats.Controls.Add(this.txtCharStStr);
            this.tpStats.Controls.Add(this.lblI);
            this.tpStats.Controls.Add(this.lblD);
            this.tpStats.Controls.Add(this.lblS);
            this.tpStats.Location = new System.Drawing.Point(4, 22);
            this.tpStats.Name = "tpStats";
            this.tpStats.Padding = new System.Windows.Forms.Padding(3);
            this.tpStats.Size = new System.Drawing.Size(192, 156);
            this.tpStats.TabIndex = 0;
            this.tpStats.Text = "Stats";
            this.tpStats.UseVisualStyleBackColor = true;
            // 
            // txtCharGold
            // 
            this.txtCharGold.Enabled = false;
            this.txtCharGold.Location = new System.Drawing.Point(82, 115);
            this.txtCharGold.Name = "txtCharGold";
            this.txtCharGold.Size = new System.Drawing.Size(100, 20);
            this.txtCharGold.TabIndex = 13;
            this.txtCharGold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblGold
            // 
            this.lblGold.AutoSize = true;
            this.lblGold.Location = new System.Drawing.Point(7, 118);
            this.lblGold.Name = "lblGold";
            this.lblGold.Size = new System.Drawing.Size(29, 13);
            this.lblGold.TabIndex = 12;
            this.lblGold.Text = "Gold";
            // 
            // txtCharLVL
            // 
            this.txtCharLVL.Enabled = false;
            this.txtCharLVL.Location = new System.Drawing.Point(133, 11);
            this.txtCharLVL.Name = "txtCharLVL";
            this.txtCharLVL.Size = new System.Drawing.Size(49, 20);
            this.txtCharLVL.TabIndex = 11;
            this.txtCharLVL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCharStIntel
            // 
            this.txtCharStIntel.Enabled = false;
            this.txtCharStIntel.Location = new System.Drawing.Point(82, 63);
            this.txtCharStIntel.Name = "txtCharStIntel";
            this.txtCharStIntel.Size = new System.Drawing.Size(44, 20);
            this.txtCharStIntel.TabIndex = 5;
            // 
            // txtCharStDex
            // 
            this.txtCharStDex.Enabled = false;
            this.txtCharStDex.Location = new System.Drawing.Point(82, 37);
            this.txtCharStDex.Name = "txtCharStDex";
            this.txtCharStDex.Size = new System.Drawing.Size(44, 20);
            this.txtCharStDex.TabIndex = 4;
            // 
            // txtCharStStr
            // 
            this.txtCharStStr.Enabled = false;
            this.txtCharStStr.Location = new System.Drawing.Point(82, 11);
            this.txtCharStStr.Name = "txtCharStStr";
            this.txtCharStStr.Size = new System.Drawing.Size(44, 20);
            this.txtCharStStr.TabIndex = 3;
            // 
            // lblI
            // 
            this.lblI.AutoSize = true;
            this.lblI.Location = new System.Drawing.Point(7, 66);
            this.lblI.Name = "lblI";
            this.lblI.Size = new System.Drawing.Size(61, 13);
            this.lblI.TabIndex = 2;
            this.lblI.Text = "Intelligence";
            // 
            // lblD
            // 
            this.lblD.AutoSize = true;
            this.lblD.Location = new System.Drawing.Point(7, 40);
            this.lblD.Name = "lblD";
            this.lblD.Size = new System.Drawing.Size(45, 13);
            this.lblD.TabIndex = 1;
            this.lblD.Text = "Dexerity";
            // 
            // lblS
            // 
            this.lblS.AutoSize = true;
            this.lblS.Location = new System.Drawing.Point(7, 14);
            this.lblS.Name = "lblS";
            this.lblS.Size = new System.Drawing.Size(47, 13);
            this.lblS.TabIndex = 0;
            this.lblS.Text = "Strength";
            // 
            // tpInv
            // 
            this.tpInv.Controls.Add(this.lbPlayInv);
            this.tpInv.Location = new System.Drawing.Point(4, 22);
            this.tpInv.Name = "tpInv";
            this.tpInv.Padding = new System.Windows.Forms.Padding(3);
            this.tpInv.Size = new System.Drawing.Size(192, 156);
            this.tpInv.TabIndex = 1;
            this.tpInv.Text = "Inventory";
            this.tpInv.UseVisualStyleBackColor = true;
            // 
            // pbMob
            // 
            this.pbMob.InitialImage = global::Aventure_Prototype.Properties.Resources.AngrySmile_01;
            this.pbMob.Location = new System.Drawing.Point(372, 324);
            this.pbMob.MaximumSize = new System.Drawing.Size(128, 128);
            this.pbMob.Name = "pbMob";
            this.pbMob.Size = new System.Drawing.Size(128, 128);
            this.pbMob.TabIndex = 12;
            this.pbMob.TabStop = false;
            // 
            // btnShowMob
            // 
            this.btnShowMob.Location = new System.Drawing.Point(372, 465);
            this.btnShowMob.Name = "btnShowMob";
            this.btnShowMob.Size = new System.Drawing.Size(75, 23);
            this.btnShowMob.TabIndex = 13;
            this.btnShowMob.Text = "Show Mob";
            this.btnShowMob.UseVisualStyleBackColor = true;
            this.btnShowMob.Click += new System.EventHandler(this.btnShowMob_Click);
            // 
            // lblMobName
            // 
            this.lblMobName.AutoSize = true;
            this.lblMobName.Location = new System.Drawing.Point(369, 273);
            this.lblMobName.Name = "lblMobName";
            this.lblMobName.Size = new System.Drawing.Size(47, 13);
            this.lblMobName.TabIndex = 14;
            this.lblMobName.Text = "MNAME";
            // 
            // lblMobLvl
            // 
            this.lblMobLvl.AutoSize = true;
            this.lblMobLvl.Location = new System.Drawing.Point(411, 299);
            this.lblMobLvl.Name = "lblMobLvl";
            this.lblMobLvl.Size = new System.Drawing.Size(35, 13);
            this.lblMobLvl.TabIndex = 15;
            this.lblMobLvl.Text = "MLVL";
            this.lblMobLvl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblMlvl
            // 
            this.lblMlvl.AutoSize = true;
            this.lblMlvl.Location = new System.Drawing.Point(369, 299);
            this.lblMlvl.Name = "lblMlvl";
            this.lblMlvl.Size = new System.Drawing.Size(36, 13);
            this.lblMlvl.TabIndex = 16;
            this.lblMlvl.Text = "Level:";
            // 
            // txtMStr
            // 
            this.txtMStr.Enabled = false;
            this.txtMStr.Location = new System.Drawing.Point(577, 325);
            this.txtMStr.Name = "txtMStr";
            this.txtMStr.Size = new System.Drawing.Size(100, 20);
            this.txtMStr.TabIndex = 17;
            // 
            // txtMDex
            // 
            this.txtMDex.Enabled = false;
            this.txtMDex.Location = new System.Drawing.Point(577, 351);
            this.txtMDex.Name = "txtMDex";
            this.txtMDex.Size = new System.Drawing.Size(100, 20);
            this.txtMDex.TabIndex = 18;
            // 
            // txtMIntel
            // 
            this.txtMIntel.Enabled = false;
            this.txtMIntel.Location = new System.Drawing.Point(577, 377);
            this.txtMIntel.Name = "txtMIntel";
            this.txtMIntel.Size = new System.Drawing.Size(100, 20);
            this.txtMIntel.TabIndex = 19;
            // 
            // txtMHealth
            // 
            this.txtMHealth.Enabled = false;
            this.txtMHealth.Location = new System.Drawing.Point(577, 403);
            this.txtMHealth.Name = "txtMHealth";
            this.txtMHealth.Size = new System.Drawing.Size(100, 20);
            this.txtMHealth.TabIndex = 20;
            // 
            // txtMMana
            // 
            this.txtMMana.Enabled = false;
            this.txtMMana.Location = new System.Drawing.Point(577, 429);
            this.txtMMana.Name = "txtMMana";
            this.txtMMana.Size = new System.Drawing.Size(100, 20);
            this.txtMMana.TabIndex = 21;
            // 
            // lblMStr
            // 
            this.lblMStr.AutoSize = true;
            this.lblMStr.Location = new System.Drawing.Point(506, 328);
            this.lblMStr.Name = "lblMStr";
            this.lblMStr.Size = new System.Drawing.Size(47, 13);
            this.lblMStr.TabIndex = 22;
            this.lblMStr.Text = "Strength";
            // 
            // lblMDex
            // 
            this.lblMDex.AutoSize = true;
            this.lblMDex.Location = new System.Drawing.Point(506, 354);
            this.lblMDex.Name = "lblMDex";
            this.lblMDex.Size = new System.Drawing.Size(48, 13);
            this.lblMDex.TabIndex = 23;
            this.lblMDex.Text = "Dexterity";
            // 
            // lblMIntel
            // 
            this.lblMIntel.AutoSize = true;
            this.lblMIntel.Location = new System.Drawing.Point(506, 380);
            this.lblMIntel.Name = "lblMIntel";
            this.lblMIntel.Size = new System.Drawing.Size(61, 13);
            this.lblMIntel.TabIndex = 24;
            this.lblMIntel.Text = "Intelligence";
            // 
            // lblMHealth
            // 
            this.lblMHealth.AutoSize = true;
            this.lblMHealth.Location = new System.Drawing.Point(506, 406);
            this.lblMHealth.Name = "lblMHealth";
            this.lblMHealth.Size = new System.Drawing.Size(38, 13);
            this.lblMHealth.TabIndex = 25;
            this.lblMHealth.Text = "Health";
            // 
            // lblMMana
            // 
            this.lblMMana.AutoSize = true;
            this.lblMMana.Location = new System.Drawing.Point(506, 432);
            this.lblMMana.Name = "lblMMana";
            this.lblMMana.Size = new System.Drawing.Size(34, 13);
            this.lblMMana.TabIndex = 26;
            this.lblMMana.Text = "Mana";
            // 
            // btnMHit
            // 
            this.btnMHit.Location = new System.Drawing.Point(454, 464);
            this.btnMHit.Name = "btnMHit";
            this.btnMHit.Size = new System.Drawing.Size(46, 23);
            this.btnMHit.TabIndex = 27;
            this.btnMHit.Text = "HIT!";
            this.btnMHit.UseVisualStyleBackColor = true;
            this.btnMHit.Click += new System.EventHandler(this.btnMHit_Click);
            // 
            // lblMXP
            // 
            this.lblMXP.AutoSize = true;
            this.lblMXP.Location = new System.Drawing.Point(451, 273);
            this.lblMXP.Name = "lblMXP";
            this.lblMXP.Size = new System.Drawing.Size(21, 13);
            this.lblMXP.TabIndex = 28;
            this.lblMXP.Text = "XP";
            // 
            // btnAddItem
            // 
            this.btnAddItem.Location = new System.Drawing.Point(225, 373);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(100, 23);
            this.btnAddItem.TabIndex = 29;
            this.btnAddItem.Text = "Add item";
            this.btnAddItem.UseVisualStyleBackColor = true;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // btnRemItem
            // 
            this.btnRemItem.Enabled = false;
            this.btnRemItem.Location = new System.Drawing.Point(225, 406);
            this.btnRemItem.Name = "btnRemItem";
            this.btnRemItem.Size = new System.Drawing.Size(100, 23);
            this.btnRemItem.TabIndex = 30;
            this.btnRemItem.Text = "Remove item";
            this.btnRemItem.UseVisualStyleBackColor = true;
            this.btnRemItem.Click += new System.EventHandler(this.btnRemItem_Click);
            // 
            // lbPlayInv
            // 
            this.lbPlayInv.FormattingEnabled = true;
            this.lbPlayInv.Location = new System.Drawing.Point(7, 7);
            this.lbPlayInv.Name = "lbPlayInv";
            this.lbPlayInv.Size = new System.Drawing.Size(179, 134);
            this.lbPlayInv.TabIndex = 0;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 588);
            this.Controls.Add(this.btnRemItem);
            this.Controls.Add(this.btnAddItem);
            this.Controls.Add(this.lblMXP);
            this.Controls.Add(this.btnMHit);
            this.Controls.Add(this.lblMMana);
            this.Controls.Add(this.lblMHealth);
            this.Controls.Add(this.lblMIntel);
            this.Controls.Add(this.lblMDex);
            this.Controls.Add(this.lblMStr);
            this.Controls.Add(this.txtMMana);
            this.Controls.Add(this.txtMHealth);
            this.Controls.Add(this.txtMIntel);
            this.Controls.Add(this.txtMDex);
            this.Controls.Add(this.txtMStr);
            this.Controls.Add(this.lblMlvl);
            this.Controls.Add(this.lblMobLvl);
            this.Controls.Add(this.lblMobName);
            this.Controls.Add(this.btnShowMob);
            this.Controls.Add(this.pbMob);
            this.Controls.Add(this.tbChar);
            this.Controls.Add(this.lblCharMana);
            this.Controls.Add(this.lblCharHealth);
            this.Controls.Add(this.txtCharMana);
            this.Controls.Add(this.txtCharHealth);
            this.Controls.Add(this.txtCharSpec);
            this.Controls.Add(this.txtCharClass);
            this.Controls.Add(this.txtCharName);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.grbCharCr);
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.grbCharCr.ResumeLayout(false);
            this.grbCharCr.PerformLayout();
            this.gbCharStats.ResumeLayout(false);
            this.gbCharStats.PerformLayout();
            this.tbChar.ResumeLayout(false);
            this.tpStats.ResumeLayout(false);
            this.tpStats.PerformLayout();
            this.tpInv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbMob)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbCharCr;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblClSpec;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.ListBox lbClass;
        private System.Windows.Forms.ListBox lbClSpec;
        private System.Windows.Forms.GroupBox gbCharStats;
        private System.Windows.Forms.Label lblIntel;
        private System.Windows.Forms.Label lblDex;
        private System.Windows.Forms.Label lblStr;
        private System.Windows.Forms.TextBox txtMana;
        private System.Windows.Forms.TextBox txtHealth;
        private System.Windows.Forms.Label lblMana;
        private System.Windows.Forms.Label lblHealth;
        private System.Windows.Forms.TextBox txtIntel;
        private System.Windows.Forms.TextBox txtDex;
        private System.Windows.Forms.TextBox txtStr;
        private System.Windows.Forms.Button btnIntelP;
        private System.Windows.Forms.Button btnDexP;
        private System.Windows.Forms.Button btnStrP;
        private System.Windows.Forms.TextBox txtBP;
        private System.Windows.Forms.Label lblBP;
        private System.Windows.Forms.Button btnCharCon;
        private System.Windows.Forms.Button btnCharCR;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRes;
        private System.Windows.Forms.TextBox txtCharName;
        private System.Windows.Forms.TextBox txtCharClass;
        private System.Windows.Forms.TextBox txtCharSpec;
        private System.Windows.Forms.TextBox txtCharHealth;
        private System.Windows.Forms.TextBox txtCharMana;
        private System.Windows.Forms.TextBox txtCharXP;
        private System.Windows.Forms.Label lblCharHealth;
        private System.Windows.Forms.Label lblCharMana;
        private System.Windows.Forms.Label lblCharXP;
        private System.Windows.Forms.TabControl tbChar;
        private System.Windows.Forms.TabPage tpStats;
        private System.Windows.Forms.TextBox txtCharStIntel;
        private System.Windows.Forms.TextBox txtCharStDex;
        private System.Windows.Forms.TextBox txtCharStStr;
        private System.Windows.Forms.Label lblI;
        private System.Windows.Forms.Label lblD;
        private System.Windows.Forms.Label lblS;
        private System.Windows.Forms.TabPage tpInv;
        private System.Windows.Forms.TextBox txtCharLVL;
        private System.Windows.Forms.TextBox txtCharGold;
        private System.Windows.Forms.Label lblGold;
        private System.Windows.Forms.PictureBox pbMob;
        private System.Windows.Forms.Button btnShowMob;
        private System.Windows.Forms.Label lblMobName;
        private System.Windows.Forms.Label lblMobLvl;
        private System.Windows.Forms.Label lblMlvl;
        private System.Windows.Forms.TextBox txtMStr;
        private System.Windows.Forms.TextBox txtMDex;
        private System.Windows.Forms.TextBox txtMIntel;
        private System.Windows.Forms.TextBox txtMHealth;
        private System.Windows.Forms.TextBox txtMMana;
        private System.Windows.Forms.Label lblMStr;
        private System.Windows.Forms.Label lblMDex;
        private System.Windows.Forms.Label lblMIntel;
        private System.Windows.Forms.Label lblMHealth;
        private System.Windows.Forms.Label lblMMana;
        private System.Windows.Forms.Button btnMHit;
        private System.Windows.Forms.Label lblMXP;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.Button btnRemItem;
        private System.Windows.Forms.ListBox lbPlayInv;
    }
}

