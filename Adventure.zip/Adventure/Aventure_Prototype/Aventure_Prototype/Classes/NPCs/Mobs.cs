﻿/* Application - Game called: Adventure
 * Version: Prototype
 * Developer: Stoofus Games LLC
 * Coder: Jeremiah
 * Date Started: 2018/10/03
 * IDE: Visual Studio 2017 (Community Edition)
 * Lang: C#
 * 
 * File: Mobs.cs
 * Purpose Inherits methods from the NPC class
 * */

// Start namespace includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// End namespace includes

namespace Aventure_Prototype // Project namespace
{
    // Start Mobs - Inherits from NPC
    class Mobs : Main_NPC
    {
        // Start constructor of sorts
        public void mobStats(string mNewName, int mNewLevel, int mNewStrength, int mNewDexerity, int mNewIntel,
                                int mNewHealth, int mNewMana, int mNewXP)
        {
            npcName = mNewName;
            npcLevel = mNewLevel;
            npcStrength = mNewStrength;
            npcDexerity = mNewDexerity;
            npcIntel = mNewIntel;
            npcHealth = mNewHealth;
            npcMana = mNewMana;
            npcXP = mNewXP;
        } // End constructor of sorts

    } // end Mobs
}
