﻿/* Application - Game called: Adventure
 * Version: Prototype
 * Developer: Stoofus Games LLC
 * Coder: Jeremiah
 * Date Started: 2018/10/03
 * IDE: Visual Studio 2017 (Community Edition)
 * Lang: C#
 * 
 * File: Main_NPC.cs
 * Purpose Non-Playable Character class which will hold overridable perameters
 * */

// Start namespace includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// End namespace includes

namespace Aventure_Prototype // Project namespace
{

    // Top class Main_NPC for which all other NPC players wil inherit from
    public class Main_NPC
    {
        protected string npcName;
        protected int npcLevel;
        protected int npcStrength;
        protected int npcDexerity;
        protected int npcIntel;
        protected int npcHealth;
        protected int npcMana;
        protected int npcXP;

        public void SetnpcName(String pName)
        {
            npcName = pName;

        }

        public string GetnpcName()
        {
            return npcName;
        }

        public void SetnpcLevel(int pLvl)
        {
            npcLevel = pLvl;
        }

        public int GetnpcLevel()
        {
            return npcLevel;
        }

        public void SetnpcStrength(int pStr)
        {
            npcStrength = pStr;
        }

        public int GetnpcStrength()
        {
            return npcStrength;
        }

        public void SetnpcDexerity(int pDex)
        {
            npcDexerity = pDex;
        }

        public int GetnpcDexerity()
        {
            return npcDexerity;
        }

        public void SetnpcIntel(int pIntel)
        {
            npcIntel = pIntel;
        }

        public int GetnpcIntel()
        {
            return npcIntel;
        }

        public void SetnpcHealth (int pHealth)
        {
            npcHealth = pHealth;
        }

        public int GetnpcHealth()
        {
            return npcHealth;
        }

        public void SetnpcMana(int pMana)
        {
            npcMana = pMana;
        }

        public int GetnpcMana()
        {
            return npcMana;
        }

        public void SetnpcXP(int pXP)
        {
            npcXP = pXP;
        }

        public int GetnpcXP()
        {
            return npcXP;
        }
    } // End NPC class
}
