﻿/* Application - Game called: Adventure
 * Version: Prototype
 * Developer: Stoofus Games LLC
 * Coder: Jeremiah
 * Date Started: 2018/10/03
 * IDE: Visual Studio 2017 (Community Edition)
 * Lang: C#
 * 
 * File: Main_XP.cs
 * Purpose: Handles XP related tasks
 * */

// Start namespace includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// End namspace includes

namespace Aventure_Prototype.Classes.Stats // Project namespace
{
    // Top Main_XP class to handle XP related functions, methods, and inherited classes
    class Main_XP
    {
        protected int curXP;

        public void SetCurXP(int cuXP)
        {
            curXP = cuXP;
        }

        public int GetCurXP()
        {
            return curXP;
        }


    } // End Top Main_XP class
}
