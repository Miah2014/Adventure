﻿/* Application - Game called: Adventure
 * Version: Prototype
 * Developer: Stoofus Games LLC
 * Coder: Jeremiah
 * Date Started: 2018/10/03
 * IDE: Visual Studio 2017 (Community Edition)
 * Lang: C#
 * 
 * File: Main_Level.cs
 * Purpose: Handles Level related tasks
 * */

// Start namespace includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// End namspace includes

namespace Aventure_Prototype.Classes.Stats // Project namespance
{
    // Top Main_Level class to handle Level related functions, methods, and inherited classes
    class Main_Level
    {
        protected int curLevel;

        public void SetCurLevel(int cuLevel)
        {
            curLevel = cuLevel;
        }

        public int GetCurLevel()
        {
            return curLevel;
        }



    } // End Top Main_Level class
}
