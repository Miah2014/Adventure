﻿/* Application - Game called: Adventure
 * Version: Prototype
 * Developer: Stoofus Games LLC
 * Coder: Jeremiah
 * Date Started: 2018/10/03
 * IDE: Visual Studio 2017 (Community Edition)
 * Lang: C#
 * */

// Start namespace includes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
// End namespace includes

namespace Aventure_Prototype // Project namespace
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Build the main form
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Create an instance of the object frmMain
            frmMain myForm = new frmMain();

            // Create a title for myForm
            myForm.Text = "Adventure - Prototype";

            // Display the main form
            Application.Run(myForm);
        }
    }
}
