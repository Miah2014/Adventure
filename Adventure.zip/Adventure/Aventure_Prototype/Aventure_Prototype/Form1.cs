﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Aventure_Prototype.Classes.Stats;
using System.Media;

namespace Aventure_Prototype
{
    public partial class frmMain : Form
    {

        // Seeing if creating an instance of an object here is better
        // List used for lbPlayInv
        List<string> myItems = new List<string>();

        // Used to play system sounds
        SoundPlayer testBeep = new SoundPlayer(@".\Sounds\chimes.wav");

        public frmMain()
        {
            InitializeComponent();
        }

        // Start local variables
            

            // Raw Fighter stats
            int fStr = 15;
            int fDex = 10;
            int fIntel = 10;
            int fHealth = 180;
            int fMana = 20;

            // Raw Ranger stats
            int rStr = 10;
            int rDex = 15;
            int rIntel = 10;
            int rHealth = 150;
            int rMana = 50;

            // Raw Wizard stats
            int wiStr = 10;
            int wiDex = 10;
            int wiIntel = 15;
            int wiHealth = 100;
            int wiMana = 100;

            // Additional stat points based on speciality

            // Fighter - Champion: More powerful fighter
            int fCStr = 2;
            int fCHealth = 20;

            // Fighter - Knight: More technical fighter
            int fKDex = 2;
            int fKHealth = 20;

            // Ranger - Scout: More powerful ranger
            int rSStr = 2;
            int rSHealth = 20;

            // Ranger - Hunter: More technical ranger
            int rHDex = 2;
            int rHHealth = 20;

            // Wizard - BattleMage: More powerful wizard
            int wiBIntel = 2;
            int wiHHealth = 20;

            // Wizard - Conjurer: More technical wizard
            int wiCIntel = 2;
            int wiCMana = 20;

            // Ending stats
            string curStr;
            string curDex;
            string curIntel;

            // Bonus points
            int bPoints = 5;
            int tPoints = 5;

            // Char Start XP
            int curXP = 0;

            // Char Start Level
            int curLevel = 1;

            // Mob XP
            int mXP = 0;

        // End local variables

        // Start lbCLass
        private void lbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Changes the following attributes based on class selection
            // Strength, Dexterity, Intelligence, Health, and Mana
            // Speciality

            switch (lbClass.SelectedItem)
            {
                case "Fighter":
                    txtStr.Text = fStr.ToString();
                    txtDex.Text = fDex.ToString();
                    txtIntel.Text = fIntel.ToString();
                    txtHealth.Text = fHealth.ToString();
                    txtMana.Text = fMana.ToString();
                    lbClSpec.Items.Clear();
                    lbClSpec.Items.Add("Champion");
                    lbClSpec.Items.Add("Knight");
                    break;
                case "Ranger":
                    txtStr.Text = rStr.ToString();
                    txtDex.Text = rDex.ToString();
                    txtIntel.Text = rIntel.ToString();
                    txtHealth.Text = rHealth.ToString();
                    txtMana.Text = rMana.ToString();

                    lbClSpec.Items.Clear();
                    lbClSpec.Items.Add("Hunter");
                    lbClSpec.Items.Add("Scout");
                    break;
                case "Wizard":
                    txtStr.Text = wiStr.ToString();
                    txtDex.Text = wiDex.ToString();
                    txtIntel.Text = wiIntel.ToString();
                    txtHealth.Text = wiHealth.ToString();
                    txtMana.Text = wiMana.ToString();

                    lbClSpec.Items.Clear();
                    lbClSpec.Items.Add("BattleMage");
                    lbClSpec.Items.Add("Conjurer");
                    break;
                default:
                    txtStr.Text = "";
                    txtDex.Text = "";
                    txtIntel.Text = "";
                    txtHealth.Text = "";
                    txtMana.Text = "";
                    break;
            }

        } // End lbClass

        // Start btnExit
        private void btnExit_Click(object sender, EventArgs e)
        {
            // Exits the application
            //TODO - Add error trapping

            Application.Exit();

        } // End btnExit

        // Start lbClSpec
        private void lbClSpec_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Add additional stat values based on speciality selected
            // Enable the confirm button
            switch (lbClSpec.SelectedItem)
            {
                case "Champion":
                    int tfStr = fStr + fCStr;
                    int tFHealth = fHealth + fCHealth;
                    txtStr.Text = tfStr.ToString();
                    txtDex.Text = fDex.ToString();
                    txtHealth.Text = tFHealth.ToString();
                    btnCharCon.Enabled = true;
                    break;
                case "Knight":
                    int tfDex = fDex + fKDex;
                    int tFKHealth = fHealth + fCHealth;
                    txtStr.Text = fStr.ToString();
                    txtDex.Text = tfDex.ToString();
                    txtHealth.Text = tFKHealth.ToString();
                    btnCharCon.Enabled = true;
                    break;
                case "Scout":
                    int tSStr = rStr + rSStr;
                    int tRHealth = rHealth + rSHealth;
                    txtStr.Text = tSStr.ToString();
                    txtDex.Text = rDex.ToString();
                    txtHealth.Text = tRHealth.ToString();
                    btnCharCon.Enabled = true;
                    break;
                case "Hunter":
                    int tHDex = rDex + rHDex;
                    int tRHHealth = rHealth + rSHealth;
                    txtStr.Text = rStr.ToString();
                    txtDex.Text = tHDex.ToString();
                    txtHealth.Text = tRHHealth.ToString();
                    btnCharCon.Enabled = true;
                    break;
                case "BattleMage":
                    int tWIntel = wiIntel + wiBIntel;
                    int tWHealth = wiHealth + wiHHealth;
                    txtIntel.Text = tWIntel.ToString();
                    txtHealth.Text = tWHealth.ToString();
                    txtMana.Text = wiMana.ToString();
                    btnCharCon.Enabled = true;
                    break;
                case "Conjurer":
                    int tWCIntel = wiIntel + wiCIntel;
                    int tWCMana = wiMana + wiCMana;
                    txtIntel.Text = tWCIntel.ToString();
                    txtHealth.Text = wiHealth.ToString();
                    txtMana.Text = tWCMana.ToString();
                    btnCharCon.Enabled = true;
                    break;
            } // End lbClSpec
        }


        // Start btnCharCon
        private void btnCharCon_Click(object sender, EventArgs e)
        {
            // Checks that the following has values
            // txtName and txtStr <- We only care about one of the stat values as they are automatically filled
            // when a class is selected

            if (txtName.Text != "" && txtStr.Text != "")
            {
                // Disable the appropriate controls
                txtName.Enabled = false;
                lbClass.Enabled = false;
                lbClSpec.Enabled = false;

                //TODO - Change this to an undo button
                btnCharCon.Enabled = false;

                btnStrP.Enabled = true;
                btnDexP.Enabled = true;
                btnIntelP.Enabled = true;

                // Current stats
                curStr = txtStr.Text;
                curDex = txtDex.Text;
                curIntel = txtIntel.Text;

                // Add 5 bonus points
                txtBP.Text = bPoints.ToString();

            }
            else
            {
                //TODO - Add a dialog box explaining what is missing
                txtName.Enabled = true;
                lbClass.Enabled = true;
                lbClSpec.Enabled = true;
            }

            // Play a test sound
            testBeep.Play();


        } // End btnCharCon

        // Start btnStrP
        private void btnStrP_Click(object sender, EventArgs e)
        {
            // Adds points to Strength based on available bonus points

            // Check how many bonus points we have left
            // Add 1 point to Strength if we have enough
            // Do nothing if we do not have enough

            // Local variables
            string Strength;
            int s = 0;

            // Convert string to int
            Strength = txtStr.Text;
            int.TryParse(Strength, out s);

            if (bPoints != 0)
            {
                s++;
                txtStr.Text = s.ToString();
                bPoints--;
                txtBP.Text = bPoints.ToString();

            }
            if (bPoints == 0)
            {
                // Enable the Create button
                btnCharCR.Enabled = true;
            }


        } // End btnStrP

        // Start btnDexP
        private void btnDexP_Click(object sender, EventArgs e)
        {
            // Adds points to Dexerity based on available bonus points

            // Check how many bonus points we have left
            // Add 1 point to Dexerity if we have enough
            // Do nothing if we do not have enough

            // Local variables
            string Dexerity;
            int d = 0;

            // Convert string to int
            Dexerity = txtDex.Text;
            int.TryParse(Dexerity, out d);

            if (bPoints != 0)
            {
                d++;
                txtDex.Text = d.ToString();
                bPoints--;
                txtBP.Text = bPoints.ToString();
            }
            if (bPoints == 0)
            {
                // Enable the Create button
                btnCharCR.Enabled = true;
            }

        } // End btnDexP

        // Start btnIntelP
        private void btnIntelP_Click(object sender, EventArgs e)
        {
            // Adds points to Intelligence based on available bonus points

            // Check how many bonus points we have left
            // Add 1 point to Intelligence if we have enough
            // Do nothing if we do not have enough

            // Local variables
            string Intel;
            int i = 0;

            // Convert string to int
            Intel = txtIntel.Text;
            int.TryParse(Intel, out i);

            if (bPoints != 0)
            {
                i++;
                txtIntel.Text = i.ToString();
                bPoints--;
                txtBP.Text = bPoints.ToString();
            }
            if (bPoints == 0)
            {
                // Enable the Create button
                btnCharCR.Enabled = true;
            }

        } // End btnIntelP

        // Start btnRes
        private void btnRes_Click(object sender, EventArgs e)
        {
            // This will reset the bonus points back to its original value
            // Also, will reset stats to their original value

            int cS = 0;
            int cD = 0;
            int cI = 0;

            int.TryParse(curStr, out cS);
            int.TryParse(curDex, out cD);
            int.TryParse(curIntel, out cI);

            if (bPoints != tPoints)
            {
                bPoints = tPoints;
                txtBP.Text = bPoints.ToString();

                txtStr.Text = cS.ToString();
                txtDex.Text = cD.ToString();
                txtIntel.Text = cI.ToString();

                // Disable the Create button
                btnCharCR.Enabled = false;

            }

        } // End btnRes


        // Start btnCharCR
        private void btnCharCR_Click(object sender, EventArgs e)
        {
            // Finalizes the players character and starts the main game

            // Start local variables
            string charStartXP;
            charStartXP = "";
            int.TryParse(charStartXP, out curXP);

            string charGold;
            charGold = "";
            int cGold = 0;
            int.TryParse(charGold, out cGold);

            // End local variables

            // Confirm all character creation controls are disabled

            txtName.Enabled = false;
            lbClass.Enabled = false;
            lbClSpec.Enabled = false;
            btnCharCon.Enabled = false;

            txtStr.Enabled = false;
            txtDex.Enabled = false;
            txtIntel.Enabled = false;
            txtHealth.Enabled = false;
            txtMana.Enabled = false;

            btnStrP.Enabled = false;
            btnDexP.Enabled = false;
            btnIntelP.Enabled = false;

            txtBP.Enabled = false;
            btnRes.Enabled = false;

            // Display stats for player in character creation
            txtCharName.Text = txtName.Text;
            txtCharClass.Text = lbClass.Text;
            txtCharSpec.Text = lbClSpec.Text;
            txtCharHealth.Text = txtHealth.Text;
            txtCharMana.Text = txtMana.Text;

            // Display starting stats in character Stats section
            txtCharStStr.Text = txtStr.Text;
            txtCharStDex.Text = txtDex.Text;
            txtCharStIntel.Text = txtIntel.Text;

            // Starting XP
            txtCharXP.Text = curXP.ToString();

            // Starting level
            // int curLevel = 1;
            txtCharLVL.Text = curLevel.ToString();

            // Starting gold
            txtCharGold.Text = cGold.ToString();

            // Invoke main game?
            

        } // End btnCharCR

        // Start btnShowMob
        private void btnShowMob_Click(object sender, EventArgs e)
        {
            // A placeholder button to quickly show mobs

            // Name AngrySmile_01 using the Mobs class which is inherited from the NPC class
            // Create new mob object
            Mobs myMob = new Mobs();

            // Set, get, and display mob name
            myMob.SetnpcName("Angry Smile");
            lblMobName.Text = myMob.GetnpcName();

            // Set, get, and display mob attributes
            myMob.SetnpcLevel(1);
            myMob.SetnpcStrength(5);
            myMob.SetnpcDexerity(1);
            myMob.SetnpcIntel(2);
            myMob.SetnpcHealth(10);
            myMob.SetnpcMana(0);
            myMob.SetnpcXP(5);

            lblMobLvl.Text = myMob.GetnpcLevel().ToString();
            txtMStr.Text = myMob.GetnpcStrength().ToString();
            txtMDex.Text = myMob.GetnpcDexerity().ToString();
            txtMIntel.Text = myMob.GetnpcIntel().ToString();
            txtMHealth.Text = myMob.GetnpcHealth().ToString();
            txtMMana.Text = myMob.GetnpcMana().ToString();
            lblMXP.Text = "XP: " + myMob.GetnpcXP().ToString();
            mXP = myMob.GetnpcXP();

            // Enble the hit button
            btnMHit.Enabled = true;

            // Disable Show Mob button;
            btnShowMob.Enabled = false;

            // Show a new AngrySmile_01 after disposing of the current "old" one
                if (pbMob.Image != null)
                {
                    pbMob.Image.Dispose();
                }

                pbMob.Image = Properties.Resources.AngrySmile_01;

        } // End btnShowMob

        // Start btnMHit
        private void btnMHit_Click(object sender, EventArgs e)
        {
            // This will make the picture vanish and add the appropriate amount of XP to the player
            //TODO: Replace the mob with another

            if (txtMHealth.Text != "0")
            {
                btnShowMob.Enabled = false;
                btnMHit.Enabled = true;
                string curMHealth = txtMHealth.Text;
                int curMH;
                int.TryParse(curMHealth, out curMH);
                curMH--;
                txtMHealth.Text = curMH.ToString();
            }
            if (txtMHealth.Text == "0")
            {
                btnShowMob.Enabled = true;
                btnMHit.Enabled = false;
                pbMob.Image = null;
                curXP += mXP;
                txtCharXP.Text = curXP.ToString();
                
            }
        } // End btnMHit


        // Start txtCharXP_TextChanged
        private void txtCharXP_TextChanged(object sender, EventArgs e)
        {
            // Level based on XP
            // Set XP
            Main_XP myXP = new Main_XP();
            myXP.SetCurXP(curXP);

            // Get XP
            int ncurXP;
            ncurXP = myXP.GetCurXP();

            // Create a leveling instance
            Main_Level myLevel = new Main_Level();

            string pLevel;
            pLevel = txtCharLVL.Text;
            int pL;
            int.TryParse(pLevel, out pL);

            // Level up
            switch(ncurXP)
            {
                case 5:
                    
                    myLevel.SetCurLevel(pL + 1);
                    txtCharLVL.Text = myLevel.GetCurLevel().ToString();

                break;

                case 10:

                    myLevel.SetCurLevel(pL + 1);
                    txtCharLVL.Text = myLevel.GetCurLevel().ToString();
                
                break;

                case 15:

                    myLevel.SetCurLevel(pL + 1);
                    txtCharLVL.Text = myLevel.GetCurLevel().ToString();

               break;
            }



        } // End txtCharXP_TextChanged

        // Start btnAddItem
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            // Let's add an armor piece for fun
            myItems.Add("Helm");

            lbPlayInv.DataSource = null;
            lbPlayInv.DataSource = myItems;

            btnRemItem.Enabled = true;

        } // End btnAddItem

        // Start btnRemItem
        private void btnRemItem_Click(object sender, EventArgs e)
        {
            // Removes selected items

            // Create a variable to hold the selected item to be removed
            int selItem = lbPlayInv.SelectedIndex;

            try
            {
                // Remove item
                myItems.RemoveAt(selItem);
            }
            catch
            {

            }

            lbPlayInv.DataSource = null;
            lbPlayInv.DataSource = myItems;

            // If nothing to remove, disable the remove button
            if (lbPlayInv.Items.Count == 0)
            {
                btnRemItem.Enabled = false;
            }

        } // End btnRemItem
    }
}
